package com.exam.dailyquran;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.os.Build;

public class MainActivity extends ActionBarActivity {
    WebView wv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		wv=(WebView)findViewById(R.id.webView1);
		
		wv.loadUrl("http://www.knhs.edu.bd/sohag/index.php");

	}



	
	
}
